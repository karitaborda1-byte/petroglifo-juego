# Voces de piedra / Pirasumi

Videojuego de exploración 3D de petroglifos, preparado como sitio estático para GitHub Pages.

## Publicar con GitHub Pages

1. Crea un repositorio nuevo en GitHub.
2. Sube `index.html`, `THREE-LICENSE.txt` y este `README.md` a la raíz del repositorio.
3. En el repositorio, abre **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**, la rama `main` y la carpeta `/ (root)`; pulsa **Save**.
5. Espera a que termine el despliegue y abre la URL que GitHub muestra en esa misma sección.

El juego incluye Three.js y sus imágenes dentro de `index.html`; no necesita instalar paquetes ni configurar un servidor. Requiere un navegador moderno con WebGL.

## Controles

- Jugador 1: `W A S D`
- Jugador 2: flechas
- Subir o bajar de la chiva: `F` (o botón contextual). Los dos personajes viajan juntos.
- Conducir: Jugador 1 usa `W A S D`; Jugador 2 puede ayudar con las flechas; `Shift` activa el turbo.
- Correr a pie: `Shift`
- Buscar huellas: acércate a los destellos de los primeros ocho sitios y pulsa `E` / `Enter` para recogerlos. Reúne dos de tres.
- Examinar: cuando ambos estén junto a la piedra y tengan dos huellas, pulsa `E` / `Enter`. Identifica la raíz y selecciona dos rasgos visibles del registro.
- Cámara: arrastrar con el mouse; rueda para acercar o alejar
- El sonido comienza al entrar; se puede silenciar desde el botón de sonido.

## Contenido

Los diez niveles se desarrollan en un mismo mundo 3D. El progreso y las imágenes iconográficas usadas por el juego están incluidos en el HTML. Los datos iconográficos se conservan como registros de la investigación y las interpretaciones se presentan como parte de la propuesta lúdica.

El inicio del recorrido recrea una plaza de Támesis con iglesia de torre y casas de corredor, construidas en 3D con geometría del juego. Una chiva colorida recorre el territorio; acérquense y pulsen `F` para subir, conduzcan con `W A S D` y pulsen `F` para bajar. El segundo nivel incluye un puente colgante sobre una quebrada y cambia de día a noche con niebla. Cada sitio tiene un arco de piedras que enmarca el registro y fragmentos luminosos que se rastrean en el terreno. En los primeros ocho niveles, los jugadores deben reunir huellas y resolver una observación iconográfica; los dos últimos trabajan sintaxis y creación de mensajes. La poza con cascada aparece en una escena posterior. El botón **Mapa** muestra el mapa municipal de Támesis aportado a la investigación junto con la lista esquemática de sitios; no se dibujan coordenadas arqueológicas que no hayan sido documentadas.

## Licencia de Three.js

El juego incorpora Three.js r128, distribuido bajo licencia MIT. Consulta `THREE-LICENSE.txt` para el texto completo de la licencia.

